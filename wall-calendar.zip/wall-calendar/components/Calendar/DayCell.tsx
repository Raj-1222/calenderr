"use client";
import { memo } from "react";
import { format, isSameMonth } from "date-fns";

interface Props {
  day: Date;
  currentDate: Date;
  isToday: boolean;
  isStart: boolean;
  isEnd: boolean;
  isInRange: boolean;
  isCurrentMonth: boolean;
  hasNote: boolean;
  hasStickyNote: boolean;
  accent: string;
  onClick: (day: Date) => void;
  onHover: (day: Date) => void;
}

const DayCell = memo(function DayCell({
  day,
  isToday,
  isStart,
  isEnd,
  isInRange,
  isCurrentMonth,
  hasNote,
  hasStickyNote,
  accent,
  onClick,
  onHover,
}: Props) {
  const isSelected = isStart || isEnd;

  return (
    <div
      className={`
        relative flex items-center justify-center
        ${isInRange && !isSelected ? "bg-opacity-20" : ""}
        ${isStart ? "rounded-l-full" : ""}
        ${isEnd ? "rounded-r-full" : ""}
        ${isInRange ? "range-bg" : ""}
      `}
      style={
        isInRange && !isSelected
          ? { backgroundColor: `${accent}22` }
          : undefined
      }
    >
      <button
        onClick={() => onClick(day)}
        onMouseEnter={() => onHover(day)}
        className={`
          relative w-9 h-9 flex items-center justify-center rounded-full text-sm font-medium
          transition-all duration-150 select-none
          ${!isCurrentMonth ? "opacity-30" : ""}
          ${isSelected
            ? "text-white shadow-lg scale-110 font-bold"
            : isToday
            ? "font-bold"
            : "hover:bg-white/40 dark:hover:bg-white/10 hover:scale-105"
          }
          ${isInRange && !isSelected ? "text-gray-700 dark:text-gray-200" : ""}
          ${!isSelected && !isInRange ? "text-gray-700 dark:text-gray-300" : ""}
          active:scale-95 cursor-pointer
        `}
        style={
          isSelected
            ? { backgroundColor: accent, boxShadow: `0 4px 14px ${accent}66` }
            : isToday
            ? { color: accent, outline: `2px solid ${accent}`, outlineOffset: "2px" }
            : undefined
        }
        aria-label={format(day, "MMMM d, yyyy")}
      >
        {format(day, "d")}

        {/* Note indicator */}
        {(hasNote || hasStickyNote) && !isSelected && (
          <span
            className="absolute bottom-0.5 left-1/2 -translate-x-1/2 w-1 h-1 rounded-full"
            style={{ backgroundColor: accent }}
          />
        )}
      </button>
    </div>
  );
});

export default DayCell;

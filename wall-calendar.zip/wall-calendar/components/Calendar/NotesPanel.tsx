"use client";
import { useState, useEffect, useRef, useCallback } from "react";
import { format, parseISO } from "date-fns";
import { Save, Trash2, StickyNote } from "lucide-react";
import { Note } from "@/types/calendar";

interface Props {
  rangeKey: string | null;
  note: Note | null;
  accent: string;
  onSave: (key: string, content: string) => void;
  onDelete: (key: string) => void;
}

function formatRangeKey(key: string): string {
  if (!key) return "";
  const parts = key.split("_");
  if (parts.length === 1) {
    try { return format(parseISO(parts[0]), "MMMM d, yyyy"); } catch { return key; }
  }
  try {
    return `${format(parseISO(parts[0]), "MMM d")} – ${format(parseISO(parts[1]), "MMM d, yyyy")}`;
  } catch { return key; }
}

export default function NotesPanel({ rangeKey, note, accent, onSave, onDelete }: Props) {
  const [content, setContent] = useState("");
  const [savedAt, setSavedAt] = useState<string | null>(null);
  const [showSaved, setShowSaved] = useState(false);
  const autoSaveRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const savedFeedbackRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  // Track which rangeKey the current content belongs to
  const activeKeyRef = useRef<string | null>(null);

  // Only reset content when the selected date/range actually changes
  useEffect(() => {
    if (activeKeyRef.current === rangeKey) return;
    activeKeyRef.current = rangeKey;
    setContent(note?.content ?? "");
    setSavedAt(note?.updatedAt ?? null);
    setShowSaved(false);
    if (autoSaveRef.current) clearTimeout(autoSaveRef.current);
  }, [rangeKey]); // intentionally NOT depending on `note` to avoid reset loop

  const triggerSavedFeedback = useCallback(() => {
    setShowSaved(true);
    if (savedFeedbackRef.current) clearTimeout(savedFeedbackRef.current);
    savedFeedbackRef.current = setTimeout(() => setShowSaved(false), 2000);
  }, []);

  const handleChange = (val: string) => {
    setContent(val);
    setShowSaved(false);
    if (autoSaveRef.current) clearTimeout(autoSaveRef.current);
    if (rangeKey) {
      autoSaveRef.current = setTimeout(() => {
        onSave(rangeKey, val);
        setSavedAt(new Date().toISOString());
        triggerSavedFeedback();
      }, 800);
    }
  };

  const handleSave = () => {
    if (!rangeKey) return;
    if (autoSaveRef.current) clearTimeout(autoSaveRef.current);
    onSave(rangeKey, content);
    setSavedAt(new Date().toISOString());
    triggerSavedFeedback();
  };

  const handleDelete = () => {
    if (!rangeKey) return;
    if (autoSaveRef.current) clearTimeout(autoSaveRef.current);
    onDelete(rangeKey);
    setContent("");
    setSavedAt(null);
    setShowSaved(false);
    activeKeyRef.current = null; // allow re-init on next render
  };

  if (!rangeKey) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[160px] text-center px-4 py-8">
        <div
          className="w-12 h-12 rounded-2xl flex items-center justify-center mb-3 opacity-40"
          style={{ backgroundColor: `${accent}22` }}
        >
          <StickyNote size={22} style={{ color: accent }} />
        </div>
        <p className="text-sm text-gray-400 dark:text-gray-500 font-medium">
          Select a date or range to add notes
        </p>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-3">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <p className="text-xs text-gray-400 dark:text-gray-500 font-medium uppercase tracking-wider">
            Notes for
          </p>
          <p className="text-sm font-semibold text-gray-700 dark:text-gray-200 mt-0.5">
            {formatRangeKey(rangeKey)}
          </p>
        </div>
        {savedAt && (
          <p className="text-xs text-gray-400 dark:text-gray-500">
            Saved {format(parseISO(savedAt), "h:mm a")}
          </p>
        )}
      </div>

      {/* Textarea */}
      <textarea
        value={content}
        onChange={(e) => handleChange(e.target.value)}
        placeholder="Write your notes here..."
        rows={5}
        className="w-full resize-none rounded-xl p-3 text-sm
          bg-white/50 dark:bg-white/5 backdrop-blur-sm
          border border-white/60 dark:border-white/10
          text-gray-700 dark:text-gray-200
          placeholder-gray-400 dark:placeholder-gray-600
          focus:outline-none transition-all duration-150"
        style={{ boxShadow: `0 0 0 0px ${accent}` }}
        onFocus={(e) => (e.target.style.boxShadow = `0 0 0 2px ${accent}88`)}
        onBlur={(e) => (e.target.style.boxShadow = `0 0 0 0px ${accent}`)}
      />

      {/* Actions */}
      <div className="flex items-center gap-2">
        <button
          onClick={handleSave}
          className="flex items-center gap-1.5 px-4 py-2 rounded-lg text-sm font-semibold text-white
            transition-all duration-150 active:scale-95 hover:opacity-90 shadow-md"
          style={{ backgroundColor: accent, boxShadow: `0 4px 12px ${accent}44` }}
        >
          <Save size={14} />
          Save
        </button>

        {(note || content) && (
          <button
            onClick={handleDelete}
            className="flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm font-medium
              bg-red-50 dark:bg-red-900/20 text-red-500 dark:text-red-400
              hover:bg-red-100 dark:hover:bg-red-900/40
              transition-all duration-150 active:scale-95"
          >
            <Trash2 size={14} />
            Delete
          </button>
        )}

        {showSaved && (
          <span
            className="text-xs font-medium ml-auto transition-opacity duration-300"
            style={{ color: accent }}
          >
            ✓ Saved
          </span>
        )}
      </div>
    </div>
  );
}

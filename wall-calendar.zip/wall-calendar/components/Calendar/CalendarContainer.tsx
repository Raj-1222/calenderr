"use client";
import { useMemo, useEffect, useState } from "react";
import { useCalendar } from "@/hooks/useCalendar";
import { useNotes } from "@/hooks/useNotes";
import { useTheme } from "@/hooks/useTheme";
import { MONTH_DATA } from "@/lib/monthData";
import ImageBanner from "./ImageBanner";
import CalendarHeader from "./CalendarHeader";
import CalendarGrid from "./CalendarGrid";
import NotesPanel from "./NotesPanel";
import { Moon, Sun, X } from "lucide-react";

export default function CalendarContainer() {
  const { dark, toggle } = useTheme();
  const cal = useCalendar();
  const { notes, saveNote, deleteNote, getNote } = useNotes();

  const meta = MONTH_DATA[cal.currentDate.getMonth()];
  const currentRangeKey = cal.rangeKey();
  const currentNote = getNote(currentRangeKey);
  const stickyNotes = useMemo(() => ({}), []);

  // Keyboard navigation
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (e.key === "ArrowLeft") cal.goToPrevMonth();
      if (e.key === "ArrowRight") cal.goToNextMonth();
      if (e.key === "t" || e.key === "T") cal.goToToday();
      if (e.key === "Escape") cal.clearSelection();
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [cal]);

  // Animate on month change
  const [animKey, setAnimKey] = useState(0);
  const [prevMonth, setPrevMonth] = useState(cal.currentDate.getMonth());
  useEffect(() => {
    if (cal.currentDate.getMonth() !== prevMonth) {
      setAnimKey((k) => k + 1);
      setPrevMonth(cal.currentDate.getMonth());
    }
  }, [cal.currentDate, prevMonth]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-100 via-gray-50 to-slate-200 dark:from-gray-950 dark:via-slate-900 dark:to-gray-950 transition-colors duration-500 p-4 lg:p-8 flex items-center justify-center">
      {/* Theme toggle */}
      <button
        onClick={toggle}
        className="fixed top-4 right-4 z-50 p-2.5 rounded-xl
          bg-white/70 dark:bg-white/10 backdrop-blur-md
          border border-white/50 dark:border-white/20
          text-gray-600 dark:text-gray-300
          hover:scale-110 active:scale-95 transition-all duration-150 shadow-lg"
        aria-label="Toggle theme"
      >
        {dark ? <Sun size={18} /> : <Moon size={18} />}
      </button>

      {/* Main card */}
      <div className="w-full max-w-5xl">
        <div className="flex flex-col lg:flex-row gap-4 lg:gap-6">
          {/* Image Banner */}
          <ImageBanner currentDate={cal.currentDate} meta={meta} />

          {/* Right panel */}
          <div className="flex-1 flex flex-col gap-4">
            {/* Calendar card */}
            <div className="rounded-2xl lg:rounded-3xl overflow-hidden
              bg-white/60 dark:bg-white/5 backdrop-blur-xl
              border border-white/70 dark:border-white/10
              shadow-xl shadow-black/5 dark:shadow-black/30
              p-5 lg:p-6"
            >
              <CalendarHeader
                currentDate={cal.currentDate}
                accent={meta.accent}
                onPrev={cal.goToPrevMonth}
                onNext={cal.goToNextMonth}
                onToday={cal.goToToday}
              />

              <div
                key={animKey}
                style={{ animation: "fadeSlideIn 0.25s ease-out" }}
              >
                <CalendarGrid
                calendarDays={cal.calendarDays}
                currentDate={cal.currentDate}
                accent={meta.accent}
                notes={notes}
                stickyNotes={stickyNotes}
                isToday={cal.isToday}
                isStart={cal.isRangeStart}
                isEnd={cal.isRangeEnd}
                isInRange={cal.isInRange}
                isCurrentMonth={cal.isCurrentMonth}
                onDayClick={cal.handleDayClick}
                onDayHover={cal.handleDayHover}
              />
              </div>

              {/* Selection info */}
              {cal.dateRange.start && (
                <div className="mt-4 flex items-center justify-between px-1">
                  <p className="text-xs text-gray-400 dark:text-gray-500">
                    {cal.selectionState === "selecting"
                      ? "Click to set end date"
                      : cal.dateRange.end
                      ? "Range selected"
                      : "Start date selected"}
                  </p>
                  <button
                    onClick={cal.clearSelection}
                    className="flex items-center gap-1 text-xs text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 transition-colors"
                  >
                    <X size={12} />
                    Clear
                  </button>
                </div>
              )}
            </div>

            {/* Notes card */}
            <div className="rounded-2xl lg:rounded-3xl overflow-hidden
              bg-white/60 dark:bg-white/5 backdrop-blur-xl
              border border-white/70 dark:border-white/10
              shadow-xl shadow-black/5 dark:shadow-black/30
              p-5 lg:p-6"
            >
              <div className="flex items-center gap-2 mb-4">
                <div
                  className="w-2 h-2 rounded-full"
                  style={{ backgroundColor: meta.accent }}
                />
                <h3 className="text-sm font-semibold text-gray-600 dark:text-gray-300 uppercase tracking-wider">
                  Notes
                </h3>
              </div>
              <NotesPanel
                rangeKey={currentRangeKey}
                note={currentNote}
                accent={meta.accent}
                onSave={saveNote}
                onDelete={deleteNote}
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

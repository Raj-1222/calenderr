"use client";
import { useRef, useState } from "react";
import { format } from "date-fns";
import { MonthMeta } from "@/lib/monthData";

interface Props {
  currentDate: Date;
  meta: MonthMeta;
}

export default function ImageBanner({ currentDate, meta }: Props) {
  const [mousePos, setMousePos] = useState({ x: 50, y: 50 });
  const containerRef = useRef<HTMLDivElement>(null);

  const handleMouseMove = (e: React.MouseEvent) => {
    const rect = containerRef.current?.getBoundingClientRect();
    if (!rect) return;
    const x = ((e.clientX - rect.left) / rect.width) * 100;
    const y = ((e.clientY - rect.top) / rect.height) * 100;
    setMousePos({ x, y });
  };

  return (
    <div
      ref={containerRef}
      onMouseMove={handleMouseMove}
      className="relative w-full lg:w-[420px] lg:min-w-[420px] h-64 lg:h-full overflow-hidden rounded-2xl lg:rounded-3xl group"
      style={{ minHeight: "260px" }}
    >
      {/* Background image with parallax */}
      <div
        className="absolute inset-0 transition-transform duration-300 ease-out scale-110 group-hover:scale-125"
        style={{
          backgroundImage: `url(${meta.image})`,
          backgroundSize: "cover",
          backgroundPosition: `${mousePos.x}% ${mousePos.y}%`,
          transition: "background-position 0.1s ease-out, transform 0.4s ease-out",
        }}
      />

      {/* Gradient overlay */}
      <div className={`absolute inset-0 bg-gradient-to-t ${meta.gradient}`} />
      <div className="absolute inset-0 bg-gradient-to-r from-black/30 to-transparent" />

      {/* Content */}
      <div className="absolute inset-0 flex flex-col justify-end p-6 lg:p-8">
        <div className="transform translate-y-2 group-hover:translate-y-0 transition-transform duration-300">
          <p className="text-white/70 text-sm font-medium tracking-widest uppercase mb-1">
            {format(currentDate, "yyyy")}
          </p>
          <h1 className="text-white text-4xl lg:text-5xl font-bold tracking-tight leading-none">
            {format(currentDate, "MMMM")}
          </h1>
          <p className="text-white/80 text-sm mt-3 font-light italic tracking-wide">
            {meta.tagline}
          </p>
        </div>

        {/* Decorative dots */}
        <div className="absolute top-6 right-6 flex gap-1.5">
          {[0, 1, 2].map((i) => (
            <div
              key={i}
              className="w-1.5 h-1.5 rounded-full bg-white/40"
              style={{ animationDelay: `${i * 0.2}s` }}
            />
          ))}
        </div>
      </div>
    </div>
  );
}

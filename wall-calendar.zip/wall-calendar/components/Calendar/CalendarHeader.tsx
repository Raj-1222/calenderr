"use client";
import { format } from "date-fns";
import { ChevronLeft, ChevronRight, CalendarDays } from "lucide-react";

interface Props {
  currentDate: Date;
  accent: string;
  onPrev: () => void;
  onNext: () => void;
  onToday: () => void;
}

export default function CalendarHeader({ currentDate, accent, onPrev, onNext, onToday }: Props) {
  return (
    <div className="flex items-center justify-between mb-4 px-1">
      <div className="flex items-center gap-3">
        <h2 className="text-xl font-bold text-gray-800 dark:text-white tracking-tight">
          {format(currentDate, "MMMM yyyy")}
        </h2>
      </div>

      <div className="flex items-center gap-1">
        <button
          onClick={onToday}
          className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg
            bg-white/60 dark:bg-white/10 backdrop-blur-sm border border-white/40 dark:border-white/20
            text-gray-600 dark:text-gray-300 hover:bg-white/80 dark:hover:bg-white/20
            transition-all duration-150 active:scale-95"
        >
          <CalendarDays size={12} />
          Today
        </button>

        <button
          onClick={onPrev}
          className="p-2 rounded-lg bg-white/60 dark:bg-white/10 backdrop-blur-sm border border-white/40 dark:border-white/20
            text-gray-600 dark:text-gray-300 hover:bg-white/80 dark:hover:bg-white/20
            transition-all duration-150 active:scale-95 hover:scale-105"
          aria-label="Previous month"
        >
          <ChevronLeft size={16} />
        </button>

        <button
          onClick={onNext}
          className="p-2 rounded-lg bg-white/60 dark:bg-white/10 backdrop-blur-sm border border-white/40 dark:border-white/20
            text-gray-600 dark:text-gray-300 hover:bg-white/80 dark:hover:bg-white/20
            transition-all duration-150 active:scale-95 hover:scale-105"
          aria-label="Next month"
        >
          <ChevronRight size={16} />
        </button>
      </div>
    </div>
  );
}

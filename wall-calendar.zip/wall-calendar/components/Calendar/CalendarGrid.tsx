"use client";
import { memo } from "react";
import { format } from "date-fns";
import DayCell from "./DayCell";

const WEEKDAYS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

interface Props {
  calendarDays: Date[];
  currentDate: Date;
  accent: string;
  notes: Record<string, unknown>;
  stickyNotes: Record<string, unknown>;
  isToday: (d: Date) => boolean;
  isStart: (d: Date) => boolean;
  isEnd: (d: Date) => boolean;
  isInRange: (d: Date) => boolean;
  isCurrentMonth: (d: Date) => boolean;
  onDayClick: (d: Date) => void;
  onDayHover: (d: Date) => void;
}

const CalendarGrid = memo(function CalendarGrid({
  calendarDays,
  currentDate,
  accent,
  notes,
  stickyNotes,
  isToday,
  isStart,
  isEnd,
  isInRange,
  isCurrentMonth,
  onDayClick,
  onDayHover,
}: Props) {
  return (
    <div>
      {/* Weekday headers */}
      <div className="grid grid-cols-7 mb-2">
        {WEEKDAYS.map((d) => (
          <div
            key={d}
            className="text-center text-xs font-semibold text-gray-400 dark:text-gray-500 py-1 tracking-wider"
          >
            {d}
          </div>
        ))}
      </div>

      {/* Day cells */}
      <div className="grid grid-cols-7 gap-y-1">
        {calendarDays.map((day) => {
          const key = format(day, "yyyy-MM-dd");
          return (
            <DayCell
              key={key}
              day={day}
              currentDate={currentDate}
              isToday={isToday(day)}
              isStart={isStart(day)}
              isEnd={isEnd(day)}
              isInRange={isInRange(day)}
              isCurrentMonth={isCurrentMonth(day)}
              hasNote={!!notes[key]}
              hasStickyNote={!!stickyNotes[key]}
              accent={accent}
              onClick={onDayClick}
              onHover={onDayHover}
            />
          );
        })}
      </div>
    </div>
  );
});

export default CalendarGrid;

export interface DateRange {
  start: Date | null;
  end: Date | null;
}

export interface Note {
  id: string;
  dateKey: string; // "YYYY-MM-DD" or "YYYY-MM-DD_YYYY-MM-DD" for ranges
  content: string;
  updatedAt: string;
}

export interface StickyNote {
  id: string;
  dateKey: string;
  content: string;
  color: string;
}

export type SelectionState = "idle" | "selecting";

"use client";
import { useState, useLayoutEffect, useCallback } from "react";

function getInitialDark(): boolean {
  if (typeof window === "undefined") return false;
  const stored = localStorage.getItem("wall-calendar-theme");
  if (stored) return stored === "dark";
  return window.matchMedia("(prefers-color-scheme: dark)").matches;
}

function applyDark(dark: boolean) {
  if (dark) {
    document.documentElement.classList.add("dark");
  } else {
    document.documentElement.classList.remove("dark");
  }
  localStorage.setItem("wall-calendar-theme", dark ? "dark" : "light");
}

export function useTheme() {
  const [dark, setDark] = useState(false);

  // useLayoutEffect runs synchronously before paint — no flash
  useLayoutEffect(() => {
    const initial = getInitialDark();
    setDark(initial);
    applyDark(initial);
  }, []);

  const toggle = useCallback(() => {
    setDark((prev) => {
      const next = !prev;
      applyDark(next);
      return next;
    });
  }, []);

  return { dark, toggle };
}

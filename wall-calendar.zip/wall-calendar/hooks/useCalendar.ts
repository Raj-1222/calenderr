"use client";
import { useState, useCallback } from "react";
import {
  startOfMonth,
  endOfMonth,
  addMonths,
  subMonths,
  isWithinInterval,
  isSameDay,
  isToday,
  startOfWeek,
  endOfWeek,
  eachDayOfInterval,
  format,
} from "date-fns";
import { DateRange, SelectionState } from "@/types/calendar";

export function useCalendar() {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [dateRange, setDateRange] = useState<DateRange>({ start: null, end: null });
  const [hoverDate, setHoverDate] = useState<Date | null>(null);
  const [selectionState, setSelectionState] = useState<SelectionState>("idle");

  const monthStart = startOfMonth(currentDate);
  const monthEnd = endOfMonth(currentDate);
  const calStart = startOfWeek(monthStart, { weekStartsOn: 0 });
  const calEnd = endOfWeek(monthEnd, { weekStartsOn: 0 });
  const calendarDays = eachDayOfInterval({ start: calStart, end: calEnd });

  const goToPrevMonth = useCallback(() => setCurrentDate((d) => subMonths(d, 1)), []);
  const goToNextMonth = useCallback(() => setCurrentDate((d) => addMonths(d, 1)), []);
  const goToToday = useCallback(() => setCurrentDate(new Date()), []);

  const handleDayClick = useCallback(
    (day: Date) => {
      if (selectionState === "idle") {
        setDateRange({ start: day, end: null });
        setSelectionState("selecting");
      } else {
        if (dateRange.start && day < dateRange.start) {
          setDateRange({ start: day, end: dateRange.start });
        } else {
          setDateRange((prev) => ({ ...prev, end: day }));
        }
        setSelectionState("idle");
        setHoverDate(null);
      }
    },
    [selectionState, dateRange.start]
  );

  const handleDayHover = useCallback(
    (day: Date) => {
      if (selectionState === "selecting") setHoverDate(day);
    },
    [selectionState]
  );

  const clearSelection = useCallback(() => {
    setDateRange({ start: null, end: null });
    setSelectionState("idle");
    setHoverDate(null);
  }, []);

  const isInRange = useCallback(
    (day: Date) => {
      const end = selectionState === "selecting" && hoverDate ? hoverDate : dateRange.end;
      const start = dateRange.start;
      if (!start || !end) return false;
      const [s, e] = start <= end ? [start, end] : [end, start];
      return isWithinInterval(day, { start: s, end: e });
    },
    [dateRange, hoverDate, selectionState]
  );

  const isRangeStart = useCallback(
    (day: Date) => !!dateRange.start && isSameDay(day, dateRange.start),
    [dateRange.start]
  );

  const isRangeEnd = useCallback(
    (day: Date) => {
      const end = selectionState === "selecting" && hoverDate ? hoverDate : dateRange.end;
      return !!end && isSameDay(day, end);
    },
    [dateRange.end, hoverDate, selectionState]
  );

  const isCurrentMonth = useCallback(
    (day: Date) => day.getMonth() === currentDate.getMonth(),
    [currentDate]
  );

  const rangeKey = useCallback(() => {
    if (!dateRange.start) return null;
    if (!dateRange.end) return format(dateRange.start, "yyyy-MM-dd");
    const [s, e] =
      dateRange.start <= dateRange.end
        ? [dateRange.start, dateRange.end]
        : [dateRange.end, dateRange.start];
    return `${format(s, "yyyy-MM-dd")}_${format(e, "yyyy-MM-dd")}`;
  }, [dateRange]);

  return {
    currentDate,
    calendarDays,
    dateRange,
    hoverDate,
    selectionState,
    monthStart,
    goToPrevMonth,
    goToNextMonth,
    goToToday,
    handleDayClick,
    handleDayHover,
    clearSelection,
    isInRange,
    isRangeStart,
    isRangeEnd,
    isCurrentMonth,
    isToday,
    isSameDay,
    rangeKey,
    setCurrentDate,
  };
}

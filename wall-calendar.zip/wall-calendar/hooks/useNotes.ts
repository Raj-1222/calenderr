"use client";
import { useState, useEffect, useCallback } from "react";
import { Note } from "@/types/calendar";

const STORAGE_KEY = "wall-calendar-notes";

export function useNotes() {
  const [notes, setNotes] = useState<Record<string, Note>>({});

  useEffect(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) setNotes(JSON.parse(stored));
    } catch {}
  }, []);

  const saveNote = useCallback((dateKey: string, content: string) => {
    setNotes((prev) => {
      const updated = {
        ...prev,
        [dateKey]: {
          id: dateKey,
          dateKey,
          content,
          updatedAt: new Date().toISOString(),
        },
      };
      localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
      return updated;
    });
  }, []);

  const deleteNote = useCallback((dateKey: string) => {
    setNotes((prev) => {
      const updated = { ...prev };
      delete updated[dateKey];
      localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
      return updated;
    });
  }, []);

  const getNote = useCallback(
    (dateKey: string | null): Note | null => {
      if (!dateKey) return null;
      return notes[dateKey] ?? null;
    },
    [notes]
  );

  return { notes, saveNote, deleteNote, getNote };
}

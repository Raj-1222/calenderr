export interface MonthMeta {
  image: string;
  tagline: string;
  accent: string; // tailwind color class base
  gradient: string;
}

export const MONTH_DATA: MonthMeta[] = [
  {
    image: "https://images.unsplash.com/photo-1516912481808-3406841bd33c?w=800&q=80",
    tagline: "New beginnings await",
    accent: "#6366f1",
    gradient: "from-indigo-900/80 via-indigo-800/50 to-transparent",
  },
  {
    image: "https://images.unsplash.com/photo-1518199266791-5375a83190b7?w=800&q=80",
    tagline: "Love is in the air",
    accent: "#ec4899",
    gradient: "from-pink-900/80 via-pink-800/50 to-transparent",
  },
  {
    image: "https://images.unsplash.com/photo-1490750967868-88df5691cc5e?w=800&q=80",
    tagline: "Watch the world bloom",
    accent: "#10b981",
    gradient: "from-emerald-900/80 via-emerald-800/50 to-transparent",
  },
  {
    image: "https://images.unsplash.com/photo-1462275646964-a0e3386b89fa?w=800&q=80",
    tagline: "Spring into action",
    accent: "#84cc16",
    gradient: "from-lime-900/80 via-lime-800/50 to-transparent",
  },
  {
    image: "https://images.unsplash.com/photo-1508739773434-c26b3d09e071?w=800&q=80",
    tagline: "Adventure is calling",
    accent: "#f59e0b",
    gradient: "from-amber-900/80 via-amber-800/50 to-transparent",
  },
  {
    image: "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&q=80",
    tagline: "Sun, sea & serenity",
    accent: "#0ea5e9",
    gradient: "from-sky-900/80 via-sky-800/50 to-transparent",
  },
  {
    image: "https://images.unsplash.com/photo-1504701954957-2010ec3bcec1?w=800&q=80",
    tagline: "Peak of summer bliss",
    accent: "#f97316",
    gradient: "from-orange-900/80 via-orange-800/50 to-transparent",
  },
  {
    image: "https://images.unsplash.com/photo-1500534314209-a25ddb2bd429?w=800&q=80",
    tagline: "Golden days ahead",
    accent: "#eab308",
    gradient: "from-yellow-900/80 via-yellow-800/50 to-transparent",
  },
  {
    image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=800&q=80",
    tagline: "Harvest the moment",
    accent: "#d97706",
    gradient: "from-amber-900/80 via-orange-800/50 to-transparent",
  },
  {
    image: "https://images.unsplash.com/photo-1508739773434-c26b3d09e071?w=800&q=80",
    tagline: "Colors of change",
    accent: "#ef4444",
    gradient: "from-red-900/80 via-red-800/50 to-transparent",
  },
  {
    image: "https://images.unsplash.com/photo-1477601263568-180e2c6d046e?w=800&q=80",
    tagline: "Cozy season begins",
    accent: "#8b5cf6",
    gradient: "from-violet-900/80 via-violet-800/50 to-transparent",
  },
  {
    image: "https://images.unsplash.com/photo-1418985991508-e47386d96a71?w=800&q=80",
    tagline: "Magic in the air",
    accent: "#06b6d4",
    gradient: "from-cyan-900/80 via-blue-900/50 to-transparent",
  },
];
